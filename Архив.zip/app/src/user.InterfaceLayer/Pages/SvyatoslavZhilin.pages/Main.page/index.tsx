import React, { FC } from "react";

import Component1 from "../../../Components/SvyatoslavZhilin.components.bll/Components1.component.bll";
// import { Component1 } from "test-lib";

const MainPage: FC = () => {
	// eslint-disable-next-line no-console
	// console.log(Component1);

	return <div>SvyatoslavZhilinMainPage <Component1/></div>;
};

export default MainPage;

