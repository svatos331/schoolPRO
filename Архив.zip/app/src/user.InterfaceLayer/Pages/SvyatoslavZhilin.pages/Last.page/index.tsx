import React, { FC } from "react";

const LastPage: FC = () => <div> SvyatoslavZhilinLastPage </div>;

export default LastPage;
