enum Colors {
	WHITE = "#FFFFFF",
	BLACK = "#000000",
}

export default Colors;
