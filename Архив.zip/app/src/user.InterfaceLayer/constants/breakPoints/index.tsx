enum BreakPoints {
	SMALL_MOBILE = 359,
	MOBILE = 979,
	TABLET = 1439,
}

export default BreakPoints;
