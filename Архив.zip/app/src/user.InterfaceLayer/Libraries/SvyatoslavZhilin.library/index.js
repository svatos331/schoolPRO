import React from "react";
import ReactDOM from "react-dom/client";

const element = document.getElementById("app");
const root = ReactDOM.createRoot(element);

root.render(
	<React.StrictMode>
		<div>123</div>
	</React.StrictMode>
);
