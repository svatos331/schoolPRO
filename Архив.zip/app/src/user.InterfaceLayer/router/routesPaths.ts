enum RoutesPaths {
	NOT_FOUND = "*",
	MAIN = "/",
	DEFAULT = "",
	SVYATOSLAV_ZHILIN = "/svyatoslavZhilin",
}

export default RoutesPaths;
