enum svyatoslavZhilinRoutesPaths {
	LAST = "last",
}

export default svyatoslavZhilinRoutesPaths;
