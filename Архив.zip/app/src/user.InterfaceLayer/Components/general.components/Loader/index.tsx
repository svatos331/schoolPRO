import React from "react";

import * as ST from "./styled";

const Loader = () => <ST.Loader>Загрузка</ST.Loader>;

export default Loader;
