import React, {Children, cloneElement, useMemo} from "react";

import {
	useGetTodoQuery,
	useLazyGetTodoQuery
} from "../../../../business.InterfaceLayer/store/shared/entities/svyatoslavZhilin.entities/todo.entity/redux/api";

const Component1 = () => {
	const {data} = useGetTodoQuery({ authToken: "", params: { id: "1" } });
	const [request] = useLazyGetTodoQuery();


	// eslint-disable-next-line no-console
	console.log(321,test);
	// eslint-disable-next-line no-console
	console.log(123, data);


	const props = useMemo(()=>{
		return {	data: data || false,
			request,
			isLoading: !data,};
	},[data]);

	return (
		<div>
			{Children.toArray(children).map((child) => cloneElement(child, props))}
		</div>
	);
};

export default Component1;

