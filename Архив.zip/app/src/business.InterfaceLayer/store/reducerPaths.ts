enum reducerPaths {
	todo = "todo",
}

export default reducerPaths;
