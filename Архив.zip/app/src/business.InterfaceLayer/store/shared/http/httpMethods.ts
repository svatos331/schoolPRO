enum httpMethods {
	GET = "GET",
	PATCH = "PATCH",
	POST = "POST",
	DELETE = "DELETE",
	PUT = "PUT",
}

export default httpMethods;
