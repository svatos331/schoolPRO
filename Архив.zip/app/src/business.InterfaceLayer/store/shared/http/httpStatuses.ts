enum httpStatuses {
	UNAUTHORIZED = 401,
	SUCCESS = 200,
	SUCCESS_201 = 201,
	PENDING = 202,
}

export default httpStatuses;
