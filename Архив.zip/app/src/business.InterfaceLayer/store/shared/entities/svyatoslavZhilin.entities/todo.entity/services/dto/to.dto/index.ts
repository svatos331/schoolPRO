
export const todoToDtoServiceArray = (props: any) => {
	return props;
};

export const todoFromDtoServiceObject = (props: any) => {
	return props;
};
