export interface ITodoDTO {
	id: string;
	name: string;
}

export const todoFromDtoServiceArray = (props: any):ITodoDTO => {
	return props;
};

export const todoFromDtoServiceObject = (props: any) => {
	return props;
};
