enum url {
	todo = "/todos",
}

export default url;
