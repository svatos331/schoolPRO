module.exports = {
	trailingComma: "es5",
	tabWidth: 2,
	semi: true,
	singleAttributePerLine: true,
	useTabs: true,
	printWidth: 80,
	endOfLine: "lf",
};

